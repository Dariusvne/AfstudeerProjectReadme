package com.swisscom.travelmate.engine.shared.external;

public enum AuthStyle {
    Basic,
    Body
}
